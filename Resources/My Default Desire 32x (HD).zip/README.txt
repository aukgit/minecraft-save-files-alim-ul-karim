
	================================================
	This README will have My Default Desire 32x (HD)
	and Faithful working harmoniously together!
	================================================

 1. DOWNLOAD Faithful (required):

	https://minecraft.curseforge.com/projects/faithful-vanilla

 2. ASK: "How do I use both packs?"

	https://postimg.org/image/dva1km635/



